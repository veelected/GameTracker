package aquino.vladimir.example.xenobladever3;

import java.util.ArrayList;

public class ExpmanList extends ArrayList {
    String[] ExpmanListBig = {
            "Item:" + "Pouch Expansion Kit 3"
                    + "\nInfo:" + "Fast Travel to Boulderbore Gate"
            ,

            "Item:" + "Pouch Expansion Kit 4"
                    + "\nInfo:" + "Ride the moving island until you reach the one with the chest"
            ,

            "Item:" + "Pouch Expansion Kit 5"
                    + "\nInfo:" + "Beneath the staircase"
            ,

            "Item:" + "Pouch Expansion Kit 6"
                    + "\nInfo:"
            ,

            "Item:" + "Nimble Nopon Get Girls"
                    + "\nInfo:" + "Chest by the Travel Point"
            ,

            "Item:" + "Artificial Blade Report"
                    + "\nInfo:" + "4th floor on the balcony"
            ,

            "Item:" + "Ether R&D Revolution"
                    + "\nInfo:" + "In the Storage Room"
            ,

            "Item:" + "Robolab Club Quarterly"
                    + "\nInfo:" + "West end of the skybridge"
            ,

            "Item:" + "Hypertech Made Easy"
                    + "\nInfo:" + "Down the elevator in the room with Haywire Radclyffe"
            ,

    };
}
