package aquino.vladimir.example.xenobladever3;

import java.util.ArrayList;

public class BladeList extends ArrayList {

    String[] BladesListBig = {
            "Blade:" + "Finch" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Shield Hammer"
            ,
            "Blade:" + "Perceval" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Chroma Katana"
            ,
            "Blade:Poppibuster" +
                    "\nRole:Tank" +
                    "\nWeapon:Shield Hammer"
            ,

            "Blade:" + "Floren" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Bitball",

            "Blade:" + "Dagas" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Greataxe",

            "Blade:" + "Azami" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Ether Cannon",

            "Blade:" + "Nim" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Knuckle Claws",

            "Blade:" + "Electra" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Shield Hammer",

            "Blade:" + "Perun" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Megalance",


            "Blade:" + "Adenine" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Knuckle Claws",


            "Blade:" + "Newt" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Chroma Katana",

            "Blade:" + "Gorg" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Greataxe",

            "Blade:" + "Kora" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Knuckle Claws",

            "Blade:" + "Vess" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Bitball",

            "Blade:" + "Boreas" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Bitball",

            "Blade:" + "Vale" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Megalance",

            "Blade:" + "Wulfric" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Megalance",

            "Blade:" + "Herald" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Ether Cannon",

            "Blade:" + "Godfrey" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Shield Hammer",

            "Blade:" + "Zenobia" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Greataxe",


            "Blade:" + "Praxis" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Megalance",

            "Blade:" + "Theory" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Chroma Katana",

            "Blade:" + "Sheba" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Ether Cannon",


            "Blade:" + "Agate" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Greataxe",

            "Blade:" + "Kasandra" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Shield Hammer",


            "Blade:" + "Dahlia" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Bitball",

            "Blade:" + "Ursula" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Knuckle Claws",

            "Blade:" + "KOS-MOS" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Ether Cannon",


            "Blade:" + "T-elos" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Greataxe",

            "Blade:" + "Poppibuster" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Shield Hammer",

            "Blade:" + "Shulk" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Monado",

            "Blade:" + "Fiora" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Knives",


            "Blade:" + "Crossette" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Bitball",

            "Blade:" + "Corvin" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Halteclere",


            "Blade:" + "Elma" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Archetype Ralzes",

            "Blade:" + "Obrona" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Brilliant TwinBlade's",

            "Blade:" + "Sever" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Sword Tonfa",

            "Blade:" + "Perdido" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Decimation Cannon",


            "Blade:" + "Cressidus" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Rockrending Gauntlets",

            "Blade:" + "Akhos" +
                    "\nRole:" + "Healer" +
                    "\nWeapon:" + "Calamity Scythe",


            "Blade:" + "Patroka" +
                    "\nRole:" + "Attacker" +
                    "\nWeapon:" + "Cobra Bardiche",

            "Blade:" + "Mikhail" +
                    "\nRole:" + "Tank" +
                    "\nWeapon:" + "Infinity Fans"
            ,
    };
}
