package aquino.vladimir.example.xenobladever3;

public class DeedsList {
    String[] DeedsListBig = {
            "Area:" + "Goldmouth"
                    + "\nBenefit:" + "Increases Dev Point gains by one."
                    + "\nMerc:" + "Long-Awaited Work"
                    + "\nShop:" + "Honeycomb Sweets"
            ,
            "Area:" + "Goldmouth"
                    + "\nBenefit:" + "Increases Idea Point gains by one."
                    + "\nMerc:" + "Long-Awaited Work New Sounds"
                    + "\nShop:" + "Reedirait Bookstore"
            ,

            "Area:" + "Goldmouth"
                    + "\nBenefit:" + "Increases Idea Point gains by one."
                    + "\nMerc:" + ""
                    + "\nShop:" + "Fishy Fishy"
            ,

            "Area:" + "Goldmouth"
                    + "\nBenefit:" + "Increases capacity for lifestyle items by ten."
                    + "\nMerc:" + "Cooking Display First Class Freshness!"
                    + "\nShop:" + "Nopox Hobby Store"
            ,

            "Area:" + "Goldmouth"
                    + "\nBenefit:" + "Decreases enemy detection range by 5%."
                    + "\nMerc:" + "New Sounds Old Routes"
                    + "\nShop:" + "Strummer Instruments"
            ,

            "Area:" + "Goldmouth"
                    + "\nBenefit:" + "Increases item drop collection range by 50cm."
                    + "\nMerc:" + "First Class Freshness!"
                    + "\nShop:" + "Cleo's Cosmetics"
            ,

            "Area:" + "Goldmouth"
                    + "\nBenefit:" + "Increases battle experience by 10%."
                    + "\nMerc:" + "Cooking Display Old Routes"
                    + "\nShop:" + "Rumbletum Canteen"
            ,

            "Area:" + "Goldmouth"
                    + "\nBenefit:" + "Increases item discovery rate by 10%"
                    + "\nMerc:" + "Must finish 12 Brothersisterpons"
                    + "\nShop:" + "12 Brothersisterpon"
            ,

            "Area:" + "Torigoth"
                    + "\nBenefit:" + "Increases item drop collection range by 50cm."
                    + "\nMerc:" + ""
                    + "\nShop:" + "Llysiau Greens"
            ,

            "Area:" + "Torigoth"
                    + "\nBenefit:" + "Increases running speed by 5%."
                    + "\nMerc:" + "Raddon Family The Water City"
                    + "\nShop:" + "Soniarus Music"
            ,

            "Area:" + "Torigoth"
                    + "\nBenefit:" + "Increases item drop collection range by 50cm."
                    + "\nMerc:" + "The Water City"
                    + "\nShop:" + "Tomi Fishmongers"
            ,

            "Area:" + "Torigoth"
                    + "\nBenefit:" + "Decreases out-of-battle Party Gauge drain rate by 25%."
                    + "\nMerc:" + "Raddon Family The Water City"
                    + "\nShop:" + "Café Savvy"
            ,

            "Area:" + "Torigoth"
                    + "\nBenefit:" + "Increases item discovery rate by 10%."
                    + "\nMerc:" + "Turf War Protection The Water City"
                    + "\nShop:" + "Cmalaf Artwork"
            ,

            "Area:" + "Torigoth"
                    + "\nBenefit:" + "Increases running speed by 5%."
                    + "\nMerc:" + "Turf War Protection Our Daily Bread (Quest)"
                    + "\nShop:" + "Tilly Bakery"
            ,

            "Area:" + "Torigoth"
                    + "\nBenefit:" + "Increases lure range by 2m."
                    + "\nMerc:" + "Raddon Family Farming Tech"
                    + "\nShop:" + "Gryff Butchers"
            ,

            "Area:" + "Torigoth"
                    + "\nBenefit:" + "Increases battle experience by 10%."
                    + "\nMerc:" + "Renowned Goods Farming Tech"
                    + "\nShop:" + "Cosmetipolitan"
            ,

            "Area:" + "Torigoth"
                    + "\nBenefit:" + "Increases gold earned in battle by 10%."
                    + "\nMerc:" + "Renowned Goods Farming Tech"
                    + "\nShop:" + "Neuromin Textiles"
            ,

            "Area:" + "Garfont Village"
                    + "\nBenefit:" + "Increases gold earned in battle by 10%."
                    + "\nMerc:" + ""
                    + "\nShop:" + "Fallone Crafts"
            ,

            "Area:" + "Garfont Village"
                    + "\nBenefit:" + "Decreases enemy detection range by 5%."
                    + "\nMerc:" + "Latest Craze"
                    + "\nShop:" + "Vibrattio Instruments"
            ,

            "Area:" + "Garfont Village"
                    + "\nBenefit:" + "Increases lure range by 2m."
                    + "\nMerc:" + "Fad Foods"
                    + "\nShop:" + "Vargel Tavern"
            ,

            "Area:" + "Garfont Village"
                    + "\nBenefit:" + "Increases Dev Point gains by one."
                    + "\nMerc:" + "Bumper Crop Secret Route"
                    + "\nShop:" + "Sadecott Groceries"
            ,

            "Area:" + "Fonsa Myma"
                    + "\nBenefit:" + "Increases running speed by 5%."
                    + "\nMerc:" + ""
                    + "\nShop:" + "Hobby Knick-Knacks"
            ,

            "Area:" + "Fonsa Myma"
                    + "\nBenefit:" + "Reduces terrain damage by 10%."
                    + "\nMerc:" + "Latest Craze Shipping Lanes Closed"
                    + "\nShop:" + "Aquaneze Cosmetics"
            ,

            "Area:" + "Fonsa Myma"
                    + "\nBenefit:" + "Decreases out-of-battle Party Gauge drain rate by 25%."
                    + "\nMerc:" + "Shipping Lanes Closed"
                    + "\nShop:" + "Sprintsy Sweets"
            ,

            "Area:" + "Fonsa Myma"
                    + "\nBenefit:" + "Increases item drop collection range by 50cm."
                    + "\nMerc:" + "Bumper Crop Beneath the Cloud Sea"
                    + "\nShop:" + "Volty Butchers"
            ,

            "Area:" + "Fonsa Myma"
                    + "\nBenefit:" + "Increases gold earned in battle by 10%."
                    + "\nMerc:" + "Shipping Lanes Closed Beneath the Cloud Sea"
                    + "\nShop:" + "Maluria Antiques"
            ,

            "Area:" + "Fonsa Myma"
                    + "\nBenefit:" + "Increases gold earned in battle by 10%."
                    + "\nMerc:" + "Fad Foods Secret Route"
                    + "\nShop:" + "Ikthus Fishmongers"
            ,

            "Area:" + "Fonsa Myma"
                    + "\nBenefit:" + "Increases lure range by 2m."
                    + "\nMerc:" + "Bumper Crop Secret Route"
                    + "\nShop:" + "Aldomar Books"
            ,

            "Area:" + "Fonsa Myma"
                    + "\nBenefit:" + "Increases item discovery rate by 10%."
                    + "\nMerc:" + "Fad Foods Secret Route"
                    + "\nShop:" + "Brad Flatforms"
            ,

            "Area:" + "Alba Cavanich"
                    + "\nBenefit:" + "Max Booster items raised by ten."
                    + "\nMerc:" + ""
                    + "\nShop:" + "Bassani Butchers"
            ,

            "Area:" + "Alba Cavanich"
                    + "\nBenefit:" + "Increases lure range by 2m."
                    + "\nMerc:" + "Shipping Lane Safety Cold Storage"
                    + "\nShop:" + "Salter Sweets"
            ,

            "Area:" + "Alba Cavanich"
                    + "\nBenefit:" + "Reduces terrain damage by 10%."
                    + "\nMerc:" + "Shipyard Security"
                    + "\nShop:" + "Haskefell Books"
            ,

            "Area:" + "Alba Cavanich"
                    + "\nBenefit:" + "Increases item discovery rate by 10%."
                    + "\nMerc:" + "Shipyard Security Cold Storage"
                    + "\nShop:" + "Elgeschel Hobby Store"
            ,

            "Area:" + "Alba Cavanich"
                    + "\nBenefit:" + "Decreases out-of-battle Party Gauge drain rate by 25%."
                    + "\nMerc:" + "Shipping Lane Safety Secret Spice"
                    + "\nShop:" + "Yafush Antiques"
            ,

            "Area:" + "Alba Cavanich"
                    + "\nBenefit:" + "Max Booster items raised by ten."
                    + "\nMerc:" + "Shipyard Security Cold Storage"
                    + "\nShop:" + "Hanoon Fishmongers"
            ,

            "Area:" + "Alba Cavanich"
                    + "\nBenefit:" + "Decreases enemy detection range by 5%."
                    + "\nMerc:" + "Secret Spice White and Cold"
                    + "\nShop:" + "Griogair's Greens"
            ,

            "Area:" + "Alba Cavanich"
                    + "\nBenefit:" + "Increases item drop collection range by 50cm."
                    + "\nMerc:" + "Secret Spice White and Cold"
                    + "\nShop:" + "Adelno Music"
            ,

            "Area:" + "Fonsett Village"
                    + "\nBenefit:" + "Increases running speed by 5%."
                    + "\nMerc:" + "Merchant Ship"
                    + "\nShop:" + "Coral Leaf Fresh Fish"
            ,

            "Area:" + "Fonsett Village"
                    + "\nBenefit:" + "Reduces terrain damage by 10%."
                    + "\nMerc:" + "Nopon Cooking Ship Lane Sighting"
                    + "\nShop:" + "Speck Butchers"
            ,

            "Area:" + "Fonsett Village"
                    + "\nBenefit:" + "Increases lure range by 2m."
                    + "\nMerc:" + "Nopon Cooking Ship Lane Sighting"
                    + "\nShop:" + "Future Crafts"
            ,

            "Area:" + "Fonsett Village"
                    + "\nBenefit:" + "Increases Idea Point gains by one."
                    + "\nMerc:" + ""
                    + "\nShop:" + "Talmye Antiques"
            ,

            "Area:" + "Fonsett Village"
                    + "\nBenefit:" + "Increases gold earned in battle by 10%."
                    + "\nMerc:" + "Nopon Cooking Sinking Storehouse?"
                    + "\nShop:" + "Corcaja Greengrocers"
            ,

            "Area:" + "Fonsett Village"
                    + "\nBenefit:" + "Decreases enemy detection range by 5%."
                    + "\nMerc:" + "Weathered Ship Wagon Guard"
                    + "\nShop:" + "Cafe Lutino"
            ,

            "Area:" + "Theosoir"
                    + "\nBenefit:" + "Increases battle experience by 10%."
                    + "\nMerc:" + "Weathered Ship"
                    + "\nShop:" + "Lectica Vegetables"
            ,

            "Area:" + "Theosoir"
                    + "\nBenefit:" + "Increases capacity for lifestyle items by ten."
                    + "\nMerc:" + "Weathered Ship Beat the Heat"
                    + "\nShop:" + "Placks Patisserie"
            ,

            "Area:" + "Theosoir"
                    + "\nBenefit:" + "Decreases out-of-battle Party Gauge drain rate by 25%."
                    + "\nMerc:" + "Frozen Door Beat the Heat"
                    + "\nShop:" + "Platini Deli"
            ,

            "Area:" + "Theosoir"
                    + "\nBenefit:" + "Increases battle experience by 10%."
                    + "\nMerc:" + "Frozen Door Cuisine Researcher"
                    + "\nShop:" + "Tatraty Fish"
            ,

            "Area:" + "Theosoir"
                    + "\nBenefit:" + "Increases running speed by 5%."
                    + "\nMerc:" + "Crafty Developments Weathered Ship"
                    + "\nShop:" + "Biblio Paulio"
            ,

            "Area:" + "Theosoir"
                    + "\nBenefit:" + "Increases battle experience by 10%."
                    + "\nMerc:" + "Cuisine Researcher Crafty Developments"
                    + "\nShop:" + "Boldarde Textiles"
            ,

            "Area:" + "Theosoir"
                    + "\nBenefit:" + "Increases capacity for lifestyle items by ten."
                    + "\nMerc:" + ""
                    + "\nShop:" + "Praximo Cosmetics"
            ,

            "Area:" + "Theosoir"
                    + "\nBenefit:" + "Increases item discovery rate by 10%."
                    + "\nMerc:" + "Frozen Door Cuisine Researcher"
                    + "\nShop:" + "Hobby Trappers"
            ,

            "Area:" + "Theosoir"
                    + "\nBenefit:" + "Decreases enemy detection range by 5%."
                    + "\nMerc:" + "Late game only"
                    + "\nShop:" + "Memoria Art"
            ,

    };
}
