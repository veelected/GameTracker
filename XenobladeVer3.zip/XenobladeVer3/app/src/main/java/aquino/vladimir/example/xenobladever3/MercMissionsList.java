package aquino.vladimir.example.xenobladever3;

public class MercMissionsList {
    String[] MercMissionsListBig = {
            "Unloading of Goods"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Crane Repairs"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Salvaging Security"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Nopon Veggie Stir-Fry"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Canteen Job"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Port Pest Problem"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Grounded Ship Rescue"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Ship Snooping"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Avoiding Heavy Losses"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Money Money Money"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Flying Monsters"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Big Catch Opportunity"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Crane Protection"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Nopon News"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Deck Duty"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Sunken Ship Survey"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Big Ship Escort"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Cooking Up a Feast"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Lifesaving"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Vocal Lesson 1"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Vocal Lesson 2"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Vocal Lesson 3"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Vocal Lesson 4"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Vocal Lesson 5"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Looks Lesson 1"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Looks Lesson 2"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Looks Lesson 3"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Looks Lesson 4"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Looks Lesson 5"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Soul Lesson 1"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Soul Lesson 2"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Soul Lesson 3"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Soul Lesson 4"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Soul Lesson 5"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Titan Battleship Fixes"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Long-Awaited Work"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Cooking Display"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Rehearsal"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "New Sounds"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "First Class Freshness!"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Old Routes"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "On the Son's Trail!"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Three Parts"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Child Disappearances"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Sparkly Costumes"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Song Selection"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Luxury Stage"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Nopon Pop Stars"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Special Concert"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Black Nopon Search"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Adenine's Password"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Zenobia's Enemy 1"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "We Need To Talk!"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Tome of Morytha Vol. 1"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Tome of Morytha Vol. 2"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Tome of Morytha Vol. 3"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Tome of Morytha Vol. 4"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Creature of the Depths"
                    + "\nArea:" + "Argentum Trade Guild"
            ,
            "Woodworking"
                    + "\nArea:" + "Gormott Province"
            ,
            "Modeling Work"
                    + "\nArea:" + "Gormott Province"
            ,
            "Landslide Prevention"
                    + "\nArea:" + "Gormott Province"
            ,
            "Harvest Help"
                    + "\nArea:" + "Gormott Province"
            ,
            "Field Devastation"
                    + "\nArea:" + "Gormott Province"
            ,
            "Mannam Juice Delivery"
                    + "\nArea:" + "Gormott Province"
            ,
            "Wood Gathering"
                    + "\nArea:" + "Gormott Province"
            ,
            "Armu Retrieval"
                    + "\nArea:" + "Gormott Province"
            ,
            "Test of Courage"
                    + "\nArea:" + "Gormott Province"
            ,
            "Forest Fire Prevention"
                    + "\nArea:" + "Gormott Province"
            ,
            "Stranded Merchant"
                    + "\nArea:" + "Gormott Province"
            ,
            "Gormott Secret Area"
                    + "\nArea:" + "Gormott Province"
            ,
            "Protect the Holy Place"
                    + "\nArea:" + "Gormott Province"
            ,
            "Mock Maneuvers"
                    + "\nArea:" + "Gormott Province"
            ,
            "Arrest Warrant"
                    + "\nArea:" + "Gormott Province"
            ,
            "Rebel Purge"
                    + "\nArea:" + "Gormott Province"
            ,
            "Wine Delivery"
                    + "\nArea:" + "Gormott Province"
            ,
            "Phantom Fruit"
                    + "\nArea:" + "Gormott Province"
            ,
            "Weird Water"
                    + "\nArea:" + "Gormott Province"
            ,
            "Energy for Remodeling"
                    + "\nArea:" + "Gormott Province"
            ,
            "Manufacture Help"
                    + "\nArea:" + "Gormott Province"
            ,
            "Meet and Greet"
                    + "\nArea:" + "Gormott Province"
            ,
            "Chase Is On"
                    + "\nArea:" + "Gormott Province"
            ,
            "Turf War Protection"
                    + "\nArea:" + "Gormott Province"
            ,
            "Raddon Family"
                    + "\nArea:" + "Gormott Province"
            ,
            "Renowned Goods"
                    + "\nArea:" + "Gormott Province"
            ,
            "The Water City"
                    + "\nArea:" + "Gormott Province"
            ,
            "Farming tech"
                    + "\nArea:" + "Gormott Province"
            ,
            "Shipbuilding Wood"
                    + "\nArea:" + "Gormott Province"
            ,
            "Craftsman's Skills"
                    + "\nArea:" + "Gormott Province"
            ,
            "Titan Shipbuilding"
                    + "\nArea:" + "Gormott Province"
            ,
            "Local Pop Star?"
                    + "\nArea:" + "Gormott Province"
            ,
            "Zenobia's Enemy 2"
                    + "\nArea:" + "Gormott Province"
            ,
            "Tirkin Kountess 1"
                    + "\nArea:" + "Gormott Province"
            ,
            "Allies of Justice 2"
                    + "\nArea:" + "Gormott Province"
            ,
            "Got 'Em"
                    + "\nArea:" + "Gormott Province"
            ,
            "Unreturnable Money"
                    + "\nArea:" + "Gormott Province"
            ,
            "Phonex Escort"
                    + "\nArea:" + "Gormott Province"
            ,
            "Flotsam Inspection"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Lost and Found"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Containing the Chaos"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Beautiful Pearl"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Igna Investigation"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Rogue Miners"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Warehouse Work"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "King of the Spring"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Daily Training"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Giant Crab Attack"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Goods Transport"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Art Supplies"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Water Quality Check"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Wonderful Stage"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Road Repairs"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Rare Goods Repairs"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Fort Rescue"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Dream of Rice"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Source Security"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Invitation from Queen"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Rainbow Shell"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Urayan Crash Course"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Green-Thumbed Mercs"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Aristocratic Security"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Wedding Invitation"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Fad Foods"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Bumper Crop"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Shipping Lanes Closed"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Secret Route"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Beneath the Cloud Sea"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Latest Craze"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Gormotti Fugitive"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Skillful Doctor"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Surveillance"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Fashion Show"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Stage Star"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Herald Search"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Allies of Justice 1"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Allies of Justice 3"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Zenobia's Enemy 3"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Tirkin Kountess 3"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Beautiful Flower"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "First Mission"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Whose Pendant?"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "The Pendant's Owner"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Document of Worth"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Bait Battle"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Everyone Loves Floren"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Trial Run 1"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Trial Run 2"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Desserts Delivered 1"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Desserts Delivered 2"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Desserts Delivered 3"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Desserts Delivered 4"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Desserts Delivered 5"
                    + "\nArea:" + "Kingdom of Uraya"
            ,
            "Cooking Spices"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Lunch of Love"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Titan Weaponry"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "VIP Escort"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Pest Extermination"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Gondola Inspection"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Nopon Letter"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Antique Judgment"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Burned Wanted Posters"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Mining Machine"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Titan Research"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Longing for Mòrag"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Illegal Dumper"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Acquiring Rare Parts"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Street Patrols"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Scientific Development"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Hot Nopon"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Smuggler Arrest"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Lifeline to Temperantia"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Showdown at Chilsain"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Volff Tricks"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Spooky Spirits"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Invitation from Emperor"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Secret Spice"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Shipyard Security"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Shipping Lane Safety"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "White and Cold"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Cold Storage"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Find Akatsuki"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Smuggle the Scholar"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Stolen Data"
                    + "\nArea:" + "Empire of Mor Ardain",

            "Medicine Knowledge"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Brought to Justice 1"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Brought to Justice 2"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Brought to Justice 3"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Brought to Justice 4"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Unjust Organization"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "False Rumor"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Ambush"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Leg it!"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Summer Concert"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Sheba's Tea Party 1"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Sheba's Tea Party 2"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Sheba's Tea Party 3"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Sheba's Tea Party 4"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Sheba's Tea Party 5"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Zenobia's Enemy 4"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Tirkin Kountess 2"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Allies of Justice 5"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Round Up"
                    + "\nArea:" + "Empire of Mor Ardain"
            ,
            "Materials Stakeout"
                    + "\nArea:" + "Empire of Mor Ardain",

            "Graveside Flowers"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Heavy Angling"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Lost Property"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Field Pests"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Taminbi Theft"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Insect Professor"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Parisax Extermination"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Pending Payout"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Shellfish Savior"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Vessel Scrapping"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Memory Bracelet"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Rex's Condition"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Research Results"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Suspicious Ship"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Dringworm Hunting"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Yashima Festival"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Energy Investigation"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Night Visitors"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Elpys Investigation"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Cloud Sea Noises"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Direct Line Escort"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "The Beast of Regideria"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Holy Choir"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Benefit Concert"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Nopon Cooking"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Merchant Ship"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Ship Lane Lighting"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Wagon Guard"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Sinking Storehouse?"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Allies of Justice 4"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Can't Escape"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Obstinate Pursuit"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Catch a Crook"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Guard the Field"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Extract a Confession"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Reclamation"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Seeding"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Growing"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Electra's Strategy"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Zenobia's Strategy"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Round 2 at Merclibay"
                    + "\nArea:" + "Leftherian Archipelago"
            ,
            "Ether Furnace Checks"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Children's Snowsuit"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Snow Removal"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Exiting Tantal"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Warming Stralu"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Snow Flower"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Carnivorous Beast"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "New Book"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Blizzard Zone"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Cold-Proof Crops"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Military Training"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "The Black Market"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Dandes Salt Cave"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Snow Survey"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Shaking Icicles"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Confidential Documents"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Book Writing"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "World in a Book"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Ice Hunter"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Mysterious Lifeform"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Crossing Bridges"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Frozen Door"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Weathered Ship"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Cuisine Researcher"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Beat the Heat"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Crafty Developments"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Tirkin Kountess 4"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Allies of Justice 6"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Fake Vase"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Finch's Big News"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
            "Arach-no-More"
                    + "\nArea:" + "Kingdom of Tantal"
            ,
    };
}
