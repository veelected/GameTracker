package aquino.vladimir.example.xenobladever3;

import java.util.ArrayList;

public class SecretAreaList extends ArrayList {
    String[] SecretListBig = {

            "Secret Area:" + "Gormott Province (Upper Level - Right)",

            "Secret Area:" + "Gormott Province (Upper Level - Right)"
            ,

            "Secret Area:" + "Kingdom of Uraya (Head)"
            ,

            "Secret Area:" + "Kingdom of Uraya (Stomach)"
            ,

            "Secret Area:" + "Empire of Mor Ardain (Alba Cavanich)"
            ,

            "Secret Area:" + "Empire of Mor Ardain (Lower Level)"
            ,

            "Secret Area:" + "Empire of Mor Ardain (Upper Level)"
            ,

            "Secret Area:" + "Empire of Mor Ardain (Lower Level)"
            ,

            "Secret Area:" + "Empire of Mor Ardain (Old Factory)"
            ,

            "Secret Area:" + "Temperantia (Ruins of Judicium)"
            ,

    };
}